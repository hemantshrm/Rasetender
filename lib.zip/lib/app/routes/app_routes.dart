part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  static const HOME = _Paths.HOME;
  static const LOGIN = _Paths.LOGIN;
  static const FORGOT_PASS = _Paths.FORGOT_PASS;
  static const SIGN_UP = _Paths.SIGN_UP;
}

abstract class _Paths {
  static const HOME = '/home';
  static const LOGIN = '/login';
  static const FORGOT_PASS = '/forgot-pass';
  static const SIGN_UP = '/sign-up';
}
